EMPLOYEE PAYROLL SYSTEM - FRONTEND

Open index.html in a browser. It is a complete standalone website interface.
Login page: login.html (demo: admin/admin123).
Data is stored in browser localStorage for demonstration.
Pages: Dashboard, Employees, Departments, Attendance, Salary, Payroll, Payments.

For Oracle integration, use the SQL scripts in Backend and the APEX notes in APEX.
