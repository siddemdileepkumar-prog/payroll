# Employee Payroll System

This project contains a standalone frontend demonstration and a complete Oracle SQL backend.

## Frontend

Open `Frontend/index.html` in Chrome/Edge and use the sidebar to view Employees, Departments, Attendance, Salary, Payroll and Payments.

The standalone frontend stores demonstration data in browser `localStorage`.

## Oracle Backend

The `Backend` folder contains the complete database implementation:

1. `00_reset_database.sql` - optional reset
2. `01_create_tables.sql` - table creation
3. `02_insert_data.sql` - sample data including Salary, Payroll and Payment
4. `03_queries.sql` - reports and joins
5. `04_transactions_ACID.sql` - transaction demonstration
6. `05_backend_test.sql` - validation
7. `README_BACKEND.md` - backend instructions

## Database relationship

Department -> Employee -> Attendance

Employee -> Salary -> Payroll -> Payment

Net Salary = Basic Salary + Allowance - Deduction

## Oracle execution

Run the SQL files in the order listed above in Oracle SQL Developer or SQL*Plus.

If the existing tables are already present and you want to rebuild them, run `00_reset_database.sql` first.

## Real frontend-to-Oracle connection

The supplied standalone HTML frontend is not itself an Oracle client. A real production connection requires an API/backend layer such as Node.js + Express + OracleDB, Java Spring Boot, or Oracle APEX.
