# Oracle Backend - Employee Payroll System

## Correct execution order

1. `00_reset_database.sql` - optional; use only if you want to delete and recreate the existing tables.
2. `01_create_tables.sql` - creates all six tables.
3. `02_insert_data.sql` - inserts departments, employees, attendance, salary, payroll and payment data.
4. `03_queries.sql` - run reports and demonstrate joins.
5. `04_transactions_ACID.sql` - demonstrates SAVEPOINT, COMMIT and ROLLBACK concepts.
6. `05_backend_test.sql` - verifies that the backend was populated correctly.

## Database relationship

DEPARTMENT -> EMPLOYEE -> ATTENDANCE

EMPLOYEE -> SALARY -> PAYROLL -> PAYMENT

## Payroll calculation

`NET SALARY = BASIC SALARY + ALLOWANCE - DEDUCTION`

## Important

The HTML frontend included in this ZIP is a standalone demonstration UI and currently stores its demo data in browser `localStorage`. The Oracle SQL backend is a separate database implementation. To make the HTML UI perform real Oracle CRUD operations, an API/backend layer (for example Node.js + Express + OracleDB, Java Spring Boot, or Oracle APEX) must be connected between the frontend and Oracle.
