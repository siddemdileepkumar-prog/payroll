-- ============================================================
-- EMPLOYEE PAYROLL MANAGEMENT SYSTEM
-- REPORTING / TEST QUERIES
-- ============================================================

-- 1. All employees with departments
SELECT e.employee_id,
       e.first_name || ' ' || e.last_name AS employee_name,
       d.department_name,
       e.designation,
       e.email,
       e.phone,
       e.joining_date,
       e.status
FROM EMPLOYEE e
JOIN DEPARTMENT d ON d.department_id = e.department_id
ORDER BY e.employee_id;

-- 2. Salary details
SELECT s.salary_id,
       e.employee_id,
       e.first_name || ' ' || e.last_name AS employee_name,
       s.basic_salary,
       s.allowance,
       s.deduction,
       s.basic_salary + s.allowance - s.deduction AS net_salary,
       s.effective_from
FROM SALARY s
JOIN EMPLOYEE e ON e.employee_id = s.employee_id
ORDER BY e.employee_id;

-- 3. Payroll details
SELECT p.payroll_id,
       e.employee_id,
       e.first_name || ' ' || e.last_name AS employee_name,
       p.payroll_month,
       p.basic_salary,
       p.allowance,
       p.deduction,
       p.net_salary,
       p.payroll_status
FROM PAYROLL p
JOIN EMPLOYEE e ON e.employee_id = p.employee_id
ORDER BY p.payroll_month DESC, e.employee_id;

-- 4. Payment details
SELECT py.payment_id,
       e.first_name || ' ' || e.last_name AS employee_name,
       p.payroll_month,
       p.net_salary,
       py.payment_date,
       py.payment_method,
       py.payment_status,
       py.transaction_reference
FROM PAYMENT py
JOIN PAYROLL p ON p.payroll_id = py.payroll_id
JOIN EMPLOYEE e ON e.employee_id = p.employee_id
ORDER BY py.payment_id;

-- 5. Pending payments
SELECT py.payment_id,
       e.first_name || ' ' || e.last_name AS employee_name,
       p.payroll_month,
       p.net_salary,
       py.payment_status
FROM PAYMENT py
JOIN PAYROLL p ON p.payroll_id = py.payroll_id
JOIN EMPLOYEE e ON e.employee_id = p.employee_id
WHERE py.payment_status = 'Pending';

-- 6. Payroll total by department
SELECT d.department_name,
       COUNT(p.payroll_id) AS employees_paid,
       SUM(p.net_salary) AS total_payroll
FROM PAYROLL p
JOIN EMPLOYEE e ON e.employee_id = p.employee_id
JOIN DEPARTMENT d ON d.department_id = e.department_id
GROUP BY d.department_name
ORDER BY d.department_name;

-- 7. Attendance report
SELECT a.attendance_id,
       e.first_name || ' ' || e.last_name AS employee_name,
       a.attendance_date,
       a.status
FROM ATTENDANCE a
JOIN EMPLOYEE e ON e.employee_id = a.employee_id
ORDER BY a.attendance_date DESC, e.employee_id;

-- 8. Complete payroll report
SELECT e.employee_id,
       e.first_name || ' ' || e.last_name AS employee_name,
       d.department_name,
       e.designation,
       p.payroll_month,
       p.basic_salary,
       p.allowance,
       p.deduction,
       p.net_salary,
       py.payment_status,
       py.payment_method
FROM EMPLOYEE e
JOIN DEPARTMENT d ON d.department_id = e.department_id
JOIN PAYROLL p ON p.employee_id = e.employee_id
LEFT JOIN PAYMENT py ON py.payroll_id = p.payroll_id
ORDER BY e.employee_id;

-- 9. Search one employee's complete salary/payment record
SELECT e.first_name || ' ' || e.last_name AS employee_name,
       s.basic_salary,
       s.allowance,
       s.deduction,
       p.payroll_month,
       p.net_salary,
       py.payment_status
FROM EMPLOYEE e
JOIN SALARY s ON s.employee_id = e.employee_id
JOIN PAYROLL p ON p.salary_id = s.salary_id
LEFT JOIN PAYMENT py ON py.payroll_id = p.payroll_id
WHERE e.email = 'ananya@company.com';
