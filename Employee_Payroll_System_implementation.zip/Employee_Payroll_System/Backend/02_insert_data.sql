-- ============================================================
-- EMPLOYEE PAYROLL MANAGEMENT SYSTEM
-- SAMPLE DATA
-- Run after 01_create_tables.sql
-- ============================================================

-- -------------------------
-- 1. DEPARTMENTS
-- -------------------------
INSERT INTO DEPARTMENT (department_name) VALUES ('Engineering');
INSERT INTO DEPARTMENT (department_name) VALUES ('Finance');
INSERT INTO DEPARTMENT (department_name) VALUES ('HR');
INSERT INTO DEPARTMENT (department_name) VALUES ('Sales');

-- -------------------------
-- 2. EMPLOYEES
-- Department IDs are obtained by name, not hard-coded.
-- -------------------------
INSERT INTO EMPLOYEE
(department_id, first_name, last_name, email, phone, designation, joining_date, status)
SELECT department_id, 'Ananya', 'Rao', 'ananya@company.com', '9876543210',
       'Software Engineer', DATE '2024-06-10', 'Active'
FROM DEPARTMENT WHERE department_name = 'Engineering';

INSERT INTO EMPLOYEE
(department_id, first_name, last_name, email, phone, designation, joining_date, status)
SELECT department_id, 'Rahul', 'Kumar', 'rahul@company.com', '9876543211',
       'Accountant', DATE '2023-08-12', 'Active'
FROM DEPARTMENT WHERE department_name = 'Finance';

INSERT INTO EMPLOYEE
(department_id, first_name, last_name, email, phone, designation, joining_date, status)
SELECT department_id, 'Priya', 'Sharma', 'priya@company.com', '9876543212',
       'HR Executive', DATE '2024-01-15', 'Active'
FROM DEPARTMENT WHERE department_name = 'HR';

INSERT INTO EMPLOYEE
(department_id, first_name, last_name, email, phone, designation, joining_date, status)
SELECT department_id, 'Arjun', 'Reddy', 'arjun@company.com', '9876543213',
       'Sales Executive', DATE '2022-11-03', 'Active'
FROM DEPARTMENT WHERE department_name = 'Sales';

-- -------------------------
-- 3. ATTENDANCE
-- -------------------------
INSERT INTO ATTENDANCE (employee_id, attendance_date, status)
SELECT employee_id, DATE '2026-10-01', 'Present'
FROM EMPLOYEE WHERE email = 'ananya@company.com';

INSERT INTO ATTENDANCE (employee_id, attendance_date, status)
SELECT employee_id, DATE '2026-10-01', 'Present'
FROM EMPLOYEE WHERE email = 'rahul@company.com';

INSERT INTO ATTENDANCE (employee_id, attendance_date, status)
SELECT employee_id, DATE '2026-10-01', 'Leave'
FROM EMPLOYEE WHERE email = 'priya@company.com';

INSERT INTO ATTENDANCE (employee_id, attendance_date, status)
SELECT employee_id, DATE '2026-10-01', 'Present'
FROM EMPLOYEE WHERE email = 'arjun@company.com';

-- -------------------------
-- 4. SALARY
-- Net salary is calculated later as:
-- Basic + Allowance - Deduction
-- -------------------------
INSERT INTO SALARY (employee_id, basic_salary, allowance, deduction, effective_from)
SELECT employee_id, 50000, 8000, 2500, DATE '2026-10-01'
FROM EMPLOYEE WHERE email = 'ananya@company.com';

INSERT INTO SALARY (employee_id, basic_salary, allowance, deduction, effective_from)
SELECT employee_id, 42000, 6000, 1800, DATE '2026-10-01'
FROM EMPLOYEE WHERE email = 'rahul@company.com';

INSERT INTO SALARY (employee_id, basic_salary, allowance, deduction, effective_from)
SELECT employee_id, 38000, 5000, 1500, DATE '2026-10-01'
FROM EMPLOYEE WHERE email = 'priya@company.com';

INSERT INTO SALARY (employee_id, basic_salary, allowance, deduction, effective_from)
SELECT employee_id, 35000, 7000, 2000, DATE '2026-10-01'
FROM EMPLOYEE WHERE email = 'arjun@company.com';

-- -------------------------
-- 5. PAYROLL
-- -------------------------
INSERT INTO PAYROLL
(employee_id, salary_id, payroll_month, basic_salary, allowance, deduction, net_salary, payroll_status)
SELECT employee_id,
       salary_id,
       '2026-10',
       basic_salary,
       allowance,
       deduction,
       basic_salary + allowance - deduction,
       'Processed'
FROM SALARY;

-- -------------------------
-- 6. PAYMENTS
-- -------------------------
INSERT INTO PAYMENT
(payroll_id, payment_date, payment_method, payment_status, transaction_reference)
SELECT p.payroll_id, DATE '2026-10-02', 'UPI', 'Paid', 'TXN10001'
FROM PAYROLL p JOIN EMPLOYEE e ON e.employee_id = p.employee_id
WHERE e.email = 'ananya@company.com' AND p.payroll_month = '2026-10';

INSERT INTO PAYMENT
(payroll_id, payment_date, payment_method, payment_status, transaction_reference)
SELECT p.payroll_id, DATE '2026-10-02', 'Bank Transfer', 'Paid', 'TXN10002'
FROM PAYROLL p JOIN EMPLOYEE e ON e.employee_id = p.employee_id
WHERE e.email = 'rahul@company.com' AND p.payroll_month = '2026-10';

INSERT INTO PAYMENT
(payroll_id, payment_date, payment_method, payment_status, transaction_reference)
SELECT p.payroll_id, NULL, NULL, 'Pending', NULL
FROM PAYROLL p JOIN EMPLOYEE e ON e.employee_id = p.employee_id
WHERE e.email = 'priya@company.com' AND p.payroll_month = '2026-10';

INSERT INTO PAYMENT
(payroll_id, payment_date, payment_method, payment_status, transaction_reference)
SELECT p.payroll_id, DATE '2026-10-02', 'UPI', 'Paid', 'TXN10004'
FROM PAYROLL p JOIN EMPLOYEE e ON e.employee_id = p.employee_id
WHERE e.email = 'arjun@company.com' AND p.payroll_month = '2026-10';

COMMIT;
