-- ============================================================
-- BACKEND VALIDATION
-- Run after 02_insert_data.sql.
-- Expected: 4 departments, 4 employees, 4 attendance,
-- 4 salaries, 4 payroll records and 4 payment records.
-- ============================================================

SELECT 'DEPARTMENT' AS table_name, COUNT(*) AS row_count FROM DEPARTMENT
UNION ALL
SELECT 'EMPLOYEE', COUNT(*) FROM EMPLOYEE
UNION ALL
SELECT 'ATTENDANCE', COUNT(*) FROM ATTENDANCE
UNION ALL
SELECT 'SALARY', COUNT(*) FROM SALARY
UNION ALL
SELECT 'PAYROLL', COUNT(*) FROM PAYROLL
UNION ALL
SELECT 'PAYMENT', COUNT(*) FROM PAYMENT;

-- Check salary-to-payroll relationship.
SELECT p.payroll_id,
       p.employee_id,
       p.salary_id,
       p.basic_salary,
       p.allowance,
       p.deduction,
       p.net_salary
FROM PAYROLL p
WHERE p.net_salary <> p.basic_salary + p.allowance - p.deduction;

-- This should return no rows if payroll is correct.
