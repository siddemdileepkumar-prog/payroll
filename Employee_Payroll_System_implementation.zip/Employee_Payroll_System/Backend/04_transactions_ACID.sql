-- ============================================================
-- TRANSACTION / ACID DEMONSTRATION
-- ============================================================

-- Example: process a pending payment.
SAVEPOINT before_payment;

UPDATE PAYMENT
SET payment_date = SYSDATE,
    payment_method = 'Bank Transfer',
    payment_status = 'Paid',
    transaction_reference = 'TXN-DEMO-001'
WHERE payment_status = 'Pending'
  AND payment_id = (
      SELECT MIN(payment_id)
      FROM PAYMENT
      WHERE payment_status = 'Pending'
  );

-- Verify the change before COMMIT.
SELECT * FROM PAYMENT ORDER BY payment_id;

-- If correct:
COMMIT;

-- If something is wrong instead, use:
-- ROLLBACK TO before_payment;
-- ROLLBACK;

-- Example rollback demonstration (do not run together with COMMIT above):
-- SAVEPOINT demo_rollback;
-- UPDATE PAYMENT SET payment_status = 'Failed' WHERE payment_id = 1;
-- ROLLBACK TO demo_rollback;
