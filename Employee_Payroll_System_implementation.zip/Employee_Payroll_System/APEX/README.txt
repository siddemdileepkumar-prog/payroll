Oracle APEX integration

The Frontend folder is a standalone website interface as requested. The Backend SQL is Oracle-compatible and can be used as the database layer for an APEX application.
Recommended APEX pages: Dashboard, Employees, Departments, Attendance, Salary, Payroll, Payments.
